package com.example.testapp.ApiService;

import com.example.testapp.model.IssPassList;
import com.example.testapp.model.IssPassModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by ctsuser1 on 12/25/17.
 */

public interface IssPassService {

    @GET("/iss-pass.json?")
    Call<IssPassList> getIssPassList(@Query("lat") double latitude, @Query("lon") double longitude);
}
