package com.example.testapp.presenter;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

import com.example.testapp.client.IssPassClient;
import com.example.testapp.model.IssPassList;
import com.example.testapp.utills.Util;
import com.example.testapp.view.IssPassView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by ctsuser1 on 12/25/17.
 */

public class IssPassPresenter implements Callback<IssPassList> {

    private IssPassClient issPassClient;
    private IssPassView issPassView;
    private Context context;
    private double longitude,latitude;
    

    public IssPassPresenter (Context context,IssPassView issPassView){
        this.context = context;
        this.issPassView = issPassView;
    }

    public void getIssPassList(double latitude,double longitude){
        issPassClient = new IssPassClient();
        if(Util.isOnline(context)) {
            //Call<IssPassList> call = issPassClient.getIssPassList(45.0, -122.3);
            Call<IssPassList> call = issPassClient.getIssPassList(latitude, longitude);
            call.enqueue(this);
        }else{
            Toast toast = Toast.makeText(context, "No Internet Connection", Toast.LENGTH_LONG);
            toast.show();
        }

    }

    @Override
    public void onResponse(Call<IssPassList> call, Response<IssPassList> response) {
        issPassView.hideProgressDialog();
        if(response.isSuccessful()){
            issPassView.renderIssPassList(response.body());
        }else {
            issPassView.renderIssPassList(null);
        }
    }

    @Override
    public void onFailure(Call<IssPassList> call, Throwable t) {
        issPassView.hideProgressDialog();
        issPassView.renderIssPassList(null);
    }

    public void getCurrentLatLong(){
        issPassView.showProgressDialog();
        LocationManager lm = (LocationManager)context.getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED)
            return;
        Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        double longitude = location.getLongitude();
        double latitude = location.getLatitude();
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 10, locationListener);
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 10, locationListener);
        getIssPassList(latitude,longitude);

    }



    private final LocationListener locationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            issPassView.hideProgressDialog();
            longitude = location.getLongitude();
            latitude = location.getLatitude();
            getIssPassList(latitude,longitude);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            issPassView.hideProgressDialog();
        }

        @Override
        public void onProviderEnabled(String provider) {
            issPassView.hideProgressDialog();
        }

        @Override
        public void onProviderDisabled(String provider) {
            issPassView.hideProgressDialog();
        }
    };


}
