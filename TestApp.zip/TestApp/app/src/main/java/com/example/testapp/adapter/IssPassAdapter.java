package com.example.testapp.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.testapp.R;
import com.example.testapp.model.IssPassModel;

import java.util.ArrayList;


/**
 * Created by ctsuser1 on 12/25/17.
 */

public class IssPassAdapter extends RecyclerView.Adapter<IssPassAdapter.IssPassViewHolder> {
    private ArrayList<IssPassModel> mIssPassModel;

    @Override
    public IssPassViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.iss_pass_item,parent,false);
        return new IssPassViewHolder(view);
    }

    @Override
    public void onBindViewHolder(IssPassViewHolder holder, int position) {
        if (mIssPassModel != null && !mIssPassModel.isEmpty()) {
            IssPassModel issPassModel = mIssPassModel.get(position);
            holder.bindUserPost(issPassModel);
        }
    }

    @Override
    public int getItemCount() {
        return mIssPassModel != null ? mIssPassModel.size() : 0;
    }

    class IssPassViewHolder extends RecyclerView.ViewHolder {

        private final TextView durationText;
        private final TextView timeStampText;

        IssPassViewHolder(View itemView) {
            super(itemView);
            durationText = itemView.findViewById(R.id.duration_text);
            timeStampText = itemView.findViewById(R.id.timeStamp_text);
        }

        void bindUserPost(IssPassModel issPassModel) {
            updateUserTitle(issPassModel);
        }

        private void updateUserTitle(IssPassModel issPassModel) {
            durationText.setText(String.valueOf(issPassModel.getDuration())+" : Seconds");
            timeStampText.setText(String.valueOf(issPassModel.getRisetime()));
        }
    }

    public void setIssPassList(ArrayList<IssPassModel> issPassModelArrayList) {
        mIssPassModel = issPassModelArrayList;
        notifyDataSetChanged();
    }
}
