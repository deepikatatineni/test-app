package com.example.testapp.view;

import com.example.testapp.model.IssPassList;

/**
 * Created by ctsuser1 on 12/25/17.
 */

public interface IssPassView {

    void showProgressDialog();

    void hideProgressDialog();

    void renderIssPassList(IssPassList issPassList);
}
