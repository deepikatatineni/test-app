package com.example.testapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.testapp.adapter.IssPassAdapter;
import com.example.testapp.model.IssPassList;
import com.example.testapp.presenter.IssPassPresenter;
import com.example.testapp.view.IssPassView;

public class IssPassActivity extends AppCompatActivity implements IssPassView{

    private IssPassPresenter issPassPresenter;
    private RecyclerView issPassListView;
    private LinearLayoutManager linearLayoutManager;
    private IssPassAdapter issPassAdapter;
    private ProgressBar progressBar;
    static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iss_pass);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);

        issPassListView = (RecyclerView) findViewById(R.id.issPass_listView);
        issPassListView.setLayoutManager(new LinearLayoutManager(this));
        issPassAdapter = new IssPassAdapter();
        issPassListView.setAdapter(issPassAdapter);
        issPassPresenter = new IssPassPresenter(IssPassActivity.this,this);
        requestPermissions();

    }

    @Override
    public void showProgressDialog() {
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressDialog() {
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void renderIssPassList(IssPassList issPassList) {
        if(issPassList!=null && issPassList.getResponse().size()>0){
            issPassAdapter.setIssPassList(issPassList.getResponse());
        }
    }

    private void requestPermissions(){
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);

            return;
        }else{
            issPassPresenter.getCurrentLatLong();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(IssPassActivity.this, "Permission was granted!", Toast.LENGTH_LONG).show();
                    issPassPresenter.getCurrentLatLong();
                    try{

                    } catch (SecurityException e) {
                        Toast.makeText(IssPassActivity.this, "SecurityException:\n" + e.toString(), Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(IssPassActivity.this, "Permission denied! - Permission required to access the current location", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }
}
