package com.example.testapp.model;

import java.util.ArrayList;

/**
 * Created by ctsuser1 on 12/25/17.
 */

public class IssPassList {

    private ArrayList<IssPassModel> response;


    public ArrayList<IssPassModel> getResponse() {
        return response;
    }

    public void setResponse(ArrayList<IssPassModel> response) {
        this.response = response;
    }

}
