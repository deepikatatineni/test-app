package com.example.testapp.model;

/**
 * Created by ctsuser1 on 12/25/17.
 */

public class IssPassModel {

    private int duration;
    private long risetime;

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public long getRisetime() {
        return risetime;
    }

    public void setRisetime(long risetime) {
        this.risetime = risetime;
    }
}
