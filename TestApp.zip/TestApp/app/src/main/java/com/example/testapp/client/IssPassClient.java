package com.example.testapp.client;

import com.example.testapp.ApiService.IssPassService;
import com.example.testapp.model.IssPassList;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class IssPassClient {

    private final String BASE_URL = "http://api.open-notify.org";
    private IssPassService issPassService;

    public IssPassClient() {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        issPassService = retrofit.create(IssPassService.class);
    }

    public Call<IssPassList> getIssPassList(double latitude,double longitude){
        return issPassService.getIssPassList(latitude, longitude);
    }

}
